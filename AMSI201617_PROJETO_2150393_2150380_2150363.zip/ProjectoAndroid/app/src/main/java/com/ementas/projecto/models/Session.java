package com.ementas.projecto.models;

/**
 * Created by xadden on 29/12/2016.
 */

public class Session {
}
